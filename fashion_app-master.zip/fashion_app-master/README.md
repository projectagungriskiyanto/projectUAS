# Flutter E-commerce Fashion 🛍
- Figma based on this project and improving it more and more,.... 
- I'm updating the functionality for it!

## 📸 Screen shot <br>

![light hi](https://user-images.githubusercontent.com/49479782/126194834-5f71c69a-310d-4c8d-9c08-e333ecc15a6f.png)


package com.app.nest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:flutter/material.dart';

class ChangePassScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

import 'package:flutter/material.dart';

class CategoryTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('a'),
    );
  }
}

import 'package:flutter/material.dart';

class AppColors{
  static const Color primaryColorRed = Color(0xffDB3022);
  static const Color primaryColorGray = Color(0xff9B9B9B);
}
